module.exports = function(includeFile){
    return require('./'+includeFile);
};