"use strict";

const adminRoutes = require("./Admin.routes");
module.exports = {
	adminRoutes: adminRoutes
};